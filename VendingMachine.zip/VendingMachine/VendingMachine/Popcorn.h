#pragma once
#include "Food.h"
class Popcorn :
	public Food
{
public:
	Popcorn();
};

