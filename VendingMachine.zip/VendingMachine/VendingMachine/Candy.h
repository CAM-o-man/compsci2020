#pragma once
#include "Food.h"
class Candy :
	public Food
{
public:
	Candy();
};

