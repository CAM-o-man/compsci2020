#include "Popcorn.h"

Popcorn::Popcorn() {
	this->name = "Popcorn";
	this->price = 6.75f;
}